$(document).ready(function(){
    $("#addFiltre").click(function(){
        $("#filtre").fadeToggle();
    });
});

function connexion()
{
    alert("vous êtes connecté");
}