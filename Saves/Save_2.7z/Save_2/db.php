<?php
	
$db = new PDO("pgsql:host=localhost;dbname=info243;","info243","8Mvyk7");

function db() {
	global $db;
	return $db;
}
