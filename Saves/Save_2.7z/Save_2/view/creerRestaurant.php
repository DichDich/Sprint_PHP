<h3 class="sous-titre">Vous pouvez ajouter un restaurant ici !</h3>

<?php 

	if(!empty($listeErreur)){
		echo "<div class='erreur'><ul>";
		foreach ($listeErreur as $k => $uneErreur) {
			echo "<li>".$uneErreur;
		}
		echo "</ul></div>";
	}

?>

<p class="info">Les champs suivis de * sont obligatoire</p>

<form action=".?r=resto/AddResto" method="post" id="formCreerResto" name="formResto">

	<label for="">Nom* : </label>
	<input type="text" id="res_nom" name="res_nom" value="" required/><br>
	<span class="info">(Doit contenir au moins 3 caractères)</span><br><br>

	<label for="res_description">Description* :</label>
	<textarea name="res_description" id="res_description" cols='50' rows='5' required></textarea><br><br>

	<label for="">Categorie prix* :</label>
	<p id="catPrix">De :<input type="text" id="res_categorieprix" name="res_categorieprix_min" value="" required placeholder="min" />€ à <input type="text" id="res_categorieprix" name="res_categorieprix_max" value="" required placeholder="max" />€</p><br>

	<label for="">Type prix* :</label>
	<select name="prx_prix">
		<?php
			foreach ($listeTypePrix as $unTypePrix => $k) {
				echo "<option value='".$k."'>".$k."</option>";
			}
		?>
	</select><br><br>

	<label for="">Telephone* :</label>
	<input type="text" id="res_tel" name="res_tel" value="" required/><br><br>

	<label for="">Site web :</label>
	<input type="text" id="res_siteweb" name="res_siteweb" value="" /><br><br>

	<label for="">Adresse mail* :</label>
	<input type="email" id="res_mel" name="res_mel" value="" required/><br><br>

	<label for="">Adresse ligne 1* :</label>
	<input type="text" id="res_adrligne1" name="res_adrligne1" value="" required/><br><br>

	<label for="">Adresse ligne 2 :</label>
	<input type="text" id="res_adrligne2" name="res_adrligne2" value="" /><br><br>

	<label for="">Code postale* :</label>
	<input type="text" id="res_cp" name="res_cp" value="" required/><br><br>

	<label for="">Ville* :</label>
	<input type="text" id="res_ville" name="res_ville" value="" required/><br><br>

	<label for="">Etat :</label>
	<input type="text" id="res_etat" name="res_etat" value="" /><br><br>

	<label for="pay_id">Pays* :</label>
	<select name="pay_id" id="pay_id" required>
	<?php
	$Pays = T_r_pays_pay::FindAll();
			foreach ($Pays as $unPays) {
				echo "<option value='".$unPays->pay_id."'>".$unPays->pay_nom."</option>";
			}
	?>
	</select><br><br>

	<input type="submit" id="submit" name="submit" value="Valider" />

</form>