<?php
// $data : liste d'abonnés

foreach($data as $unAbonnee) {
	echo $unAbonnee;


}
