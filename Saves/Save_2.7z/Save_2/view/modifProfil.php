<h3 class="sous-titre">Mon profil :</h3>
<?php 

	if(!empty($listeErreur)){
		echo "<div class='erreur'><ul>";
		foreach ($listeErreur as $k => $uneErreur) {
			echo "<li>".$uneErreur;
		}
		echo "</ul></div>";
	}

?>
<form action=".?r=user/modifPro" method="post" id="formmodifProfil" name="formProfil">
<?php
$fields = array(
	"abo_pseudo" => "Pseudo",
	"abo_nom" => "Nom",
	"abo_prenom" => "Prenom",
	"abo_mel" => "Mail",
	"abo_adrligne1" => "Adresse ligne 1",
	"abo_adrligne2" => "Adresse ligne 2",
	"abo_cp" => "Code postale",
	"abo_ville" => "Ville",
	"abo_etat" => "Etat",
	"pay_id" => "Pays",
	"abo_tel" => "Telephone",
	//"submit" => "Modifier"
);
$user = new T_e_abonne_abo($_SESSION['idCo']);
//$user = new T_e_abonne_abo(2);
foreach($fields as $field=>$label) { 
	if($label=="Pseudo" or $label=="Nom" or $label=="Prenom"){
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label>";
		echo "<input type='text' name='".$field."' value='".$user->$field."' readonly ></br>";
		echo "</p>";
	}
	elseif($label=="Pays"){
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label>";
		echo "<select name='".$field."'>";
		$Pays = T_r_pays_pay::FindAll();
		foreach ($Pays as $unPays) {
			if($unPays->pay_id == $user->pay_id)
			{
				$isSelected = "selected";
			}
			else
			{
				$isSelected = "";
			}
			echo "<option value='".$unPays->pay_id."' " . $isSelected . ">".$unPays->pay_nom."</option>";
		}
		echo "</select></br>";
		echo "</p>";
	}
	else{
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label>";
		echo "<input type='text' name='".$field."' value='".$user->$field."'><br>";
		echo "</p>";
	}
}
?>
	<input type="submit" name="valide" value="Modifier">
</form>



