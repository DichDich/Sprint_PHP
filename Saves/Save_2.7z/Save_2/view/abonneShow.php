<?php


echo $data;

