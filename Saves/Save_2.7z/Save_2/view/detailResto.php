<h1><?php echo $data->res_nom; ?></h1>
<div class="detailResto">
	<h3>Description</h3>
	<p><?php echo $data->res_description; ?></p>
	<h3>Informations</h3>
	<p>Se situe : <?php echo $data->res_adrligne1.", ".$data->res_ville.", ".$data->res_cp; ?></p>
	<p>Prix : <?php echo $data->res_categorieprix; ?></p>
	<p>Telephone : <?php echo "0".$data->res_tel; ?></p>
	<p>Mail : <?php echo $data->res_mel; ?></p>
	<?php 
		if(strlen($data->res_siteweb)>0){
			echo "<p>Site web : <a href='".$data->res_siteweb."'>".$data->res_siteweb."</a></p>";
		}
	?>
	<h3>Photos</h3>
		<form <?php echo "action='.?r=resto/addPhoto&&id=".$data->res_id."'"?> method="post" enctype="multipart/form-data">
		    Envoyez ce fichier : <input name="userfile" type="file" />
  			<input type="submit" value="Envoyer le fichier" />
		</form>

	<h3>Avis</h3>
	<!--Etre connecte pour deposer un avis -->
	<?php if(isset($_SESSION['etatConnexion'])){ ?>
		<form action=".?avis/deposer" method="post" id="formAvis">
			<p id="title">Deposer un avis</p>
			<label for="titre">Titre :</label>
			<input type="text" name="titre" id="titre" value=""><br><br>
			<label for="note">Note :</label>
			<input type="number" name="note" id="note" min="1" max="5" value="3"><span id="noteMax"> / 5</span><br><br>
			<label for="message">Message :</label>
			<textarea name="message" id="message" placeholder="Ecrivez votre message ici..."></textarea>
			<input type="submit" name="valideAvis" id="valideAvis" value="Envoyer">
		</form>
	<?php 
		}
	?>
		<div id="listAvis">
			<?php if(!empty($listAvis)){ ?>
			<div id="headerAvis">
				<p id="title">Lire un avis</p>
				<form <?php echo "action='.?".$url."'"; ?> method="post" id="triDate">
					<select name='triDate'>
						<?php
							if(isset($_POST['triDate'])&&$_POST['triDate']=="decroissant"){
								echo "<option value='decroissant'>+ Recent</option>";
								echo "<option value='croissant'>- Recent</option>";
							}
							else{
								echo "<option value='croissant'>- Recent</option>";
								echo "<option value='decroissant'>+ Recent</option>";
							}
						?>
					</select><br><br>
					<input type='submit' name='valide' value='Trier par date'>
				</form>
			</div>
	 <?php 
		 	foreach ($listAvis as $unAvis) {
		 		echo "<h4>".$unAvis->avi_titre."</h4>";
		 		foreach ($listeAbonne as $unAbo) {
		 			if($unAbo->abo_id==$unAvis->abo_id){
		 				echo "<p>Publié par : ".$unAbo->abo_pseudo."</p>";
		 			}
		 		}
		 		list($annee, $mois, $jour) = explode('-', $unAvis->avi_date);
		 		echo "<p>Publié le : ".$jour."/".$mois."/".$annee."</p>";
		 		echo "<p>Note : ".$unAvis->avi_noteglobale."/5</p>";
		 		echo "<p>".$unAvis->avi_detail."</p>";
		 		if($unAvis->avi_platsconseilles!=null){
		 			echo "<p>Vous conseil : ".$unAvis->avi_platsconseilles."</p>";
		 		}
		 	}
	 	}
	 	else{
	 		echo "Aucun avis sur ce restaurant";
	 	}
	  ?>
	</div>
</div>