<?php

$listeResto  = T_e_restaurant_res::findAll();
$listeTypeCuisine = T_r_cuisine_cui::findAll();
$listeAbonne = T_e_abonne_abo::findAll();
$listeTypePrix = T_r_typeprix_prx::listTypePrix();

$listeErreur = array();


if(isset($_GET['r']))
{

	$route = $_GET['r'];

	list($model, $action) = explode("/",$route);
	
	if($model == 'resto')
    {
		if($action =='AddResto')
        {
			if(isset($_POST['submit']))
            {
				$etatAjout = 1;
				foreach ($listeResto as $unResto) 
                {
					if($_POST["res_nom"] == $unResto->res_nom)
                    {
						$etatAjout = 0;
						$listeErreur[] = "Ce restaurant existe deja !";
					}
				}
				if($etatAjout==1)
                {
					$unRestaurant = new T_e_restaurant_res();
		            $unRestaurant->res_nom = $_POST["res_nom"];
		            $unRestaurant->res_description = $_POST["res_description"];
		            $unRestaurant->prx_prix = $_POST["prx_prix"];
		            $unRestaurant->res_categorieprix = $_POST["res_categorieprix_min"]." € - ".$_POST["res_categorieprix_max"]." €";
		            $unRestaurant->res_adrligne1 = $_POST["res_adrligne1"];
		            $unRestaurant->res_adrligne2 = $_POST["res_adrligne2"];
		            $unRestaurant->res_cp = $_POST["res_cp"];
		            $unRestaurant->res_ville = $_POST["res_ville"];
		            $unRestaurant->res_etat = $_POST["res_etat"];
		            $unRestaurant->res_tel = $_POST["res_tel"];
		            $unRestaurant->res_siteweb = $_POST["res_siteweb"];
		            $unRestaurant->pay_id = $_POST["pay_id"];
		            $unRestaurant->res_mel = $_POST["res_mel"];			
				}
				else
                {
					render('creerRestaurant');
				}
			}
			else
            {
				render("creerRestaurant");
			}
		}
		if($action=="recherche")
        {
			if(isset($_POST["valide"]) && !empty($_POST['recherche']))
            {
				$recherche = strtolower($_POST["recherche"]);

				//-------------FILTRE----------
					//-----TYPE CUISINE-----
				if($_POST['type_cuisine']!="-")
                {
					$listeResto = T_j_cuisineresto_cur::restoTypeCui($_POST['type_cuisine']);
				}

				//-------------TRI-----------
				//-----PRIX-----
				if($_POST["valide"]=="Trier par prix")
                {
					if(isset($_POST['triPrix']))
                    {
						$listeResto = trier($listeResto, "prx_prix", $_POST['triPrix']);
					}
				}
				//---------NOM---------
				if($_POST["valide"]=="Trier par nom")
                {
					if(isset($_POST['triPrix']))
                    {
						$listeResto = trier($listeResto, "res_nom", $_POST['triPrix']);
					}
				}
				
				//-------VERIFICATION---------
				foreach ($listeResto as $unResto) 
                {

					$nomResto = strtolower($unResto->res_nom);
					$nomVille = strtolower($unResto->res_ville);
					$filtreNom = strstr($nomResto, $recherche);
					$filtreVille = strstr($nomVille, $recherche);

					if($_POST['type_cuisine']!="-")
                    {
						if($filtreNom || $filtreVille){
							$data[] = $unResto;
						}
					}
					else
                    {
						if($filtreNom || $filtreVille){
							$data[] = $unResto;
						}
					}
				}
				render("resultatRecherche");
			}
			else
            {
				render("acceuil");
			}

		}
		if($action=="detail")
        {
			if(isset($_GET['id']))
            {
				$url = "r=".$route."&&id=".$_GET['id'];
				$listAvis = T_e_avis_avi::listAvisResto($_GET["id"]);
				if(isset($_POST["valide"])&&$_POST["valide"]=="Trier par date")
                {
					if(isset($_POST['triDate'])&&$_POST['triDate']=="decroissant")
                    {
						usort($listAvis, function($a, $b)
						{
						    if ($a->avi_date == $b->avi_date)
						        return 0;
						    else if ($a->avi_date > $b->avi_date)
						        return -1;
						    else              
						        return 1;
						});
					}
					else
                    {
						usort($listAvis, function($a, $b)
						{
						    if ($a->avi_date == $b->avi_date)
						        return 0;
						    else if ($a->avi_date < $b->avi_date)
						        return -1;
							else
						    	return 1;
						});
				
					}
				}
				$data = new T_e_restaurant_res($_GET["id"]);
				render('detailResto');
			}
		}
		if($action=="addPhoto"){
			$uploaddir = './';
			
			$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

			echo '<pre>';
			if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
			   echo "OK";
			} else {
			  echo "PAS OK";
			}


			print_r($_FILES);

			echo '</pre>';

			$data = new T_e_restaurant_res($_GET["id"]);
			render('detailResto');
		}
	}

	if($model == "user")
	{
		//------MODIFICATION PROFIL-------------------
		if($action == 'modifPro')
        {
			if(isset($_POST["valide"]))
            {
                $etatAjout = 1;
				foreach ($listeAbonne as $unAbo) 
                {
                    if($unAbo->abo_id != $_SESSION['idCo'])
                    {
                        if($unAbo->abo_pseudo==$_POST['abo_pseudo'])
                        {
                            $listeErreur[] = "Pseudo deja pris !";
                            $etatAjout = 0;
                        }
                        if($unAbo->abo_mel==$_POST['abo_mel'])
                        {
                            $listeErreur[] = "Email existant, veuillez saisir un autre email !";
                            $etatAjout = 0;
                        }
                    }

                }
                if(filter_var($_POST["abo_mel"], FILTER_VALIDATE_EMAIL) == false)
                {
                    $listeErreur[] = "Format mail invalide !";
                    $etatAjout = 0;
                }
                if(filter_var($_POST["abo_tel"], FILTER_SANITIZE_NUMBER_INT) == false || strlen($_POST["abo_tel"]) != 10 )
                {
                    $listeErreur[] = "Format numéro de téléphone invalide !";
                    $etatAjout = 0;
                }
				if($etatAjout==1)
                {
                    
                    $unAbonnee = new T_e_abonne_abo($_SESSION['idCo']);
                    $unAbonnee->abo_pseudo = $_POST['abo_pseudo'];
                    $unAbonnee->abo_mel = $_POST['abo_mel'];
                    $unAbonnee->abo_nom = $_POST['abo_nom'];
                    $unAbonnee->abo_prenom = $_POST['abo_prenom'];
                    $unAbonnee->abo_adrligne1 = $_POST['abo_adrligne1'];
                    $unAbonnee->abo_adrligne2 = $_POST['abo_adrligne2'];
                    $unAbonnee->abo_cp = $_POST['abo_cp'];
                    $unAbonnee->abo_ville = $_POST['abo_ville'];
                    $unAbonnee->abo_etat = $_POST['abo_etat'];
                    $unAbonnee->pay_id = $_POST['pay_id'];
                    $unAbonnee->abo_tel = $_POST['abo_tel'];
                    render("modifProfil");
                }
                else
                {
                    render("modifProfil");
                }
                //Ref Unused code
			}
			else
            {
				render("modifProfil");
			}
		}
		//----------INSCRIPTION---------------
		if($action == "inscription")
		{
			if(isset($_POST["valide"]))
			{
				$etatAjout = 1;
				foreach ($listeAbonne as $unAbo) 
                {
					if($unAbo->abo_pseudo==$_POST['abo_pseudo'])
                    {
						$listeErreur[] = "Pseudo deja pris !";
						$etatAjout = 0;
					}
					if($unAbo->abo_mel==$_POST['abo_mel'])
                    {
						$listeErreur[] = "Email existant, veuillez saisir un autre email !";
						$etatAjout = 0;
					}
                }
                if(checkMdp($_POST))
                {
                    $listeErreur[] = "Les mots de passe de correspondent pas !";
                    $etatAjout = 0;
                }                
                if(filter_var($_POST["abo_mel"], FILTER_VALIDATE_EMAIL) == false)
                {
                    $listeErreur[] = "Format mail invalide !";
                    $etatAjout = 0;
                }                
                if(filter_var($_POST["abo_tel"], FILTER_SANITIZE_NUMBER_INT) == false || strlen($_POST["abo_tel"]) > 10)
                {
                    $listeErreur[] = "Format numéro de téléphone invalide !";
                    $etatAjout = 0;
                }
				if($etatAjout==1)
                {
					$unAbonnee = new T_e_abonne_abo();
					$unAbonnee->abo_pseudo = $_POST['abo_pseudo'];
					$unAbonnee->abo_motpasse = $_POST['abo_motpasse'];
					$unAbonnee->abo_mel = $_POST['abo_mel'];
					$unAbonnee->abo_nom = $_POST['abo_nom'];
					$unAbonnee->abo_prenom = $_POST['abo_prenom'];
					$unAbonnee->abo_adrligne1 = $_POST['abo_adrligne1'];
					$unAbonnee->abo_adrligne2 = $_POST['abo_adrligne2'];
					$unAbonnee->abo_cp = $_POST['abo_cp'];
					$unAbonnee->abo_ville = $_POST['abo_ville'];
					$unAbonnee->abo_etat = $_POST['abo_etat'];
					$unAbonnee->pay_id = $_POST['pay_id'];
					$unAbonnee->abo_tel = $_POST['abo_tel'];

					$_SESSION['etatConnexion'] = 1;
					$_SESSION['idCo'] = $unAbonnee->abo_id;

					render('acceuil');
				}
				else
                {
					render('formInscription');
				}
			}
			else
			{
				render('formInscription');
			}
		}
		//------------CONNEXION---------------------
		if($action == "connexion")
        {
			if(isset($_POST['valideForm']))
            {
				$etatConnexion = 0;
				foreach ($listeAbonne as $unAbo)
                {
					if($_POST['identifiant']==$unAbo->abo_mel || $_POST['identifiant']==$unAbo->abo_pseudo)
                    {
						if($_POST['password']==$unAbo->abo_motpasse)
                        {
                            $etatConnexion = 1;
							$_SESSION['idCo'] = $unAbo->abo_id;
                            echo "<script> connexion();</script>";
						}
					}
				}
				if($etatConnexion == 1)
                {
                    $_SESSION['etatConnexion'] = 1;
					render('acceuil');
				}
                else if($etatConnexion == 0)
                {
                    $listeErreur[] = "Mauvais identifiant ou mot de passe !!";
                    render('formConnexion');
                }
				else
                {
					render('formConnexion');
				}
			}
			else
            {
				render("formConnexion");
			}	
		}

		if($action == "deco")
        {
			unset($_SESSION['etatConnexion']);
			unset($_SESSION['idCo']);
			render('acceuil');
		}

	}
}
else
{
	$data = T_e_restaurant_res::findAll();
	render("acceuil");
}

// ##################################################FONCTIONS##################################################

function render($view) {
	global $data;
	global $url;
	global $listeTypeCuisine;
	global $listeResto;
	global $listeAbonne;
	global $listAvis;
	global $listeTypePrix;
	global $listeErreur;
	include_once "view/header.php";
	include_once "view/".$view.".php";
	include_once "view/footer.php";
}

function trier($list, $attr, $val)
{
	if($val=="decroissant")
    {
		usort($list, function($a, $b) use ($attr)
		{
		    if ($a->$attr == $b->$attr)
		        return 0;
		    else if ($a->$attr > $b->$attr)
		        return -1;
		    else              
		        return 1;
		});
	}
	if($val=="croissant")
    {
		usort($list, function($a, $b) use ($attr)
		{
		    if ($a->$attr == $b->$attr)
		        return 0;
		    else if ($a->$attr < $b->$attr)
		        return -1;
			else
		    	return 1;
		});
	}
	return $list;
}

/*------------Marche pas 
foreach($_POST as $attribName => $value)
				{
				    if(in_array($attribName, get_object_vars($unAbonnee)))
				    {
				        if($inscriptArray[$attribName] )
				        	$unAbonnee->$attribName = $_POST[$attribName];
				    }
				}*/
function checkMdp($formData)
{
    foreach($formData as $fieldName => $value)
    {
        if($fieldName == "abo_motpasse")
            if($value != $formData["confirmation_motpasse"])
            {
                echo $formData["confirmation_motpasse"] . " " . $value;
                return true;
            }
    }
}
//Unused code 
				/*$aboProfil  = T_e_abonne_abo::findAll();
				$abo_mel = isset($_POST['abo_mel']);
				$abo_adrligne1 = isset($_POST['abo_adrligne1']);
				$abo_adrligne2 = isset($_POST['abo_adrligne2']);
				$abo_cp = isset($_POST['abo_cp']);
				$abo_ville = isset($_POST['abo_ville']);
				$abo_etat = isset($_POST['abo_etat']);
				$pay_id = isset($_POST['pay_id']);
				$abo_indicatif = isset($_POST['abo_indicatif']);
				$abo_tel = isset($_POST['abo_tel']);
				$abo_aeroport = isset($_POST['abo_aeroport']);
				update_abo($abo_mel, $abo_adrligne1, $abo_adrligne2, $abo_cp, $abo_ville, $abo_etat, $pay_id, $abo_indicatif, $abo_tel, $abo_aeroport );
			*/