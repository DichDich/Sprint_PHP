<?php

	session_start();
	include_once "config.php";
	include_once "db.php";
	include_once "controller/controller.php";

?>