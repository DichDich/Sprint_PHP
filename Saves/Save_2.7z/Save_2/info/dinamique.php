<?php

$fields = array(
	"res_nom" => "Nom",
	"res_description" => "Description",
	"res_categorieprix" => "Categorie prix",
	"res_adrligne1" => "Adresse ligne 1",
	"res_adrligne2" => "Adresse ligne 2",
	"res_cp" => "Code postale",
	"res_ville" => "Ville",
	"res_etat" => "Etat",
	"pay_id" => "Pays",
	"res_tel" => "Telephone",
	"res_siteweb" => "Site web",
	"res_mel" => "Adresse mail",
	"submit" => "Valider"
);

foreach($fields as $field=>$label) {
	if($label=="Description"){
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label></br>";
		echo "<textarea id='".$field."' rows='5' cols='50'></textarea>";
		echo "</p>";
	}
	elseif($label=="Valider"){
		echo "<p>";
		echo "<input type='".$field."' name='".$field."' id='".$field."' value='".$label."'/>";
		echo "</p>";
	}
	elseif($label=="Pays"){
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label></br>";
		echo "<select name='".$field."'>";
		$Pays = T_r_pays_pay::FindAll();
		foreach ($Pays as $unPays) {
			echo "<option value='".$unPays->pay_id."'>".$unPays->pay_nom."</option>";
		}
		echo "</select>";
		echo "</p>";
	}
	else{
		echo "<p>";
		echo "<label for='".$field."'>".$label." :</label></br>";
		echo "<input name='".$field."' id='".$field."'/>";
		echo "</p>";
	}
}
?>