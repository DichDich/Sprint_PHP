<?php 
class T_j_consultation_cos extends Model{
	protected abo_id;
    protected res_id;
}