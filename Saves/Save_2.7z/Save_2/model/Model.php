<?php

class Model{
	public function __construct($id = null){
		$className = strtolower(get_class($this));
		$classNameAttrib = substr($className, strlen($className)-3);
		$classNameAttrib .= "_id";
		$_SESSION["debug"] = $classNameAttrib;
		if($id!=null){
			$requette = db()->prepare("SELECT * from $className where $classNameAttrib =:id");
			$requette->bindValue(":id",$id);
			$requette->execute();
			$row = $requette->fetch(PDO::FETCH_ASSOC);
			foreach ($row as $attr => $value) {
				$this->$attr = $value;
			}
		}
		else{
			$req = db()->prepare("INSERT into $className default values returning $classNameAttrib");
			//echo "INSERT into $className default values returning $classNameAttrib";
			$req->execute();
			$row = $req->fetch();
			$this->$classNameAttrib = $row[$classNameAttrib];
		}
	}
	
	public function __get($attr){
		if(property_exists(get_class($this), $attr)){
			return $this->$attr;
		}else{
			return null;
		}
	}
	
	public function __set($attr, $value){
		if(property_exists(get_class($this), $attr)){
			$this->attr = $value;
			$className = strtolower(get_class($this));
			$classNameAttrib = substr($className, strlen($className)-3);
			$classNameAttrib .= "_id";
			$req = db()->prepare("UPDATE $className set $attr=:value where $classNameAttrib =:id");
			//echo "UPDATE $className set $attr=:value where $classNameAttrib =:id"."<br>";
			$id = $classNameAttrib;
			$req->bindValue(":id", $this->$id);
			$req->bindValue(":value", $value);
			$req->execute();
			//print_r(db()->errorInfo());
		}else{
			//die("VTFF");
		}
	}
	
	public function __toString() {
		$affich = "<ul>".get_class($this)." : ";
		foreach ($this as $attr => $value) {
			$affich .= "<li>".$attr." = ".$value;
		}
		$affich .= "</ul>";
		return $affich;
	}

	public static function findAll() {
        $className = strtolower(get_called_class());
		$table = substr($className, strlen($className)-3);
		$table .= "_id";
        $st = db()->prepare("SELECT * from $className");
        $st->execute();
        $stuffList = array();
        while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
            $stuffList[] = new $className($row[$table]);
        }
        return $stuffList;
    }
}

?>