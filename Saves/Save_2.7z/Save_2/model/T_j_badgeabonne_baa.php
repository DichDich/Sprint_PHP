<?php 
class T_j_badgeabonne_baa extends Model{
	protected abo_id;
    protected bad_id;
}