<?php 
class T_e_photo_pho extends Model{
	protected pho_id;
    protected res_id;
    protected avi_id;
    protected pho_url;
}