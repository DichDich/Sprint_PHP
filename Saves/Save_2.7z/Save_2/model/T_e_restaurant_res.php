<?php

class T_e_restaurant_res extends Model{
	protected $res_id;
	protected $prx_prix;
	protected $res_nom;
	protected $res_description;
	protected $res_categorieprix;
	protected $res_adrligne1;
	protected $res_adrligne2;
	protected $res_cp;
	protected $res_ville;
	protected $res_etat;
	protected $pay_id;
	protected $res_latitude;
	protected $res_longitude;
	protected $res_indicatif;
	protected $res_tel;
	protected $res_siteweb;
	protected $res_mel;
}