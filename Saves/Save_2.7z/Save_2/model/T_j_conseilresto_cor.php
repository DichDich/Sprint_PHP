<?php 
class T_e_photo_pho extends Model{
	protected res_id;
    protected con_id;
}