<?php
	class T_r_cuisine_cui extends Model{
		protected $cui_id;
		protected $cui_libelle;
	}