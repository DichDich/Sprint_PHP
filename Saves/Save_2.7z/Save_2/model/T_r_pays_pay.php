<?php

class T_r_pays_pay extends Model{
	protected $pay_id;
	protected $pay_nom;
}